INSERT INTO AUTH.TB_DEPARTMENT (description) VALUES
	('Leadership'), ('Sales'), ('Finance'), ('Programming'), ('Support');
