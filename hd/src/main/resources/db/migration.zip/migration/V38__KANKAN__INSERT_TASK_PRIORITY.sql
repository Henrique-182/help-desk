INSERT INTO KANBAN.TB_TASK_PRIORITY (description) VALUES
('Very High'), ('High'), ('Normal'), ('Low'), ('Very Low');
