INSERT INTO KNOWLEDGE.TB_SOFTWARE (DESCRIPTION) VALUES 
('Software A'), 
('Software B'), 
('Software C');
