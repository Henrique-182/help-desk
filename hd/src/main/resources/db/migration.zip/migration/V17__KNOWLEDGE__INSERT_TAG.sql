INSERT INTO KNOWLEDGE.TB_TAG (DESCRIPTION) VALUES
('Tag A'), 
('Tag B'),
('Tag C'), 
('Tag D'),
('Tag E'), 
('Tag F');
