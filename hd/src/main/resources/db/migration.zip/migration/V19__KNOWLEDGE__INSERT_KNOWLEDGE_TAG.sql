INSERT INTO KNOWLEDGE.TB_KNOWLEDGE_TAG (FK_KNOWLEDGE, FK_TAG) VALUES
(1, 6),
(1, 4),
(2, 1),
(2, 2),
(2, 3),
(4, 6),
(5, 4),
(6, 1);
