INSERT INTO KANBAN.TB_TASK (fk_room, description, fk_task_priority) VALUES
(1, 'Erro na geração do relatório', 4),
(3, 'Solicitou uma nova funcionalidade no sistema', 3),
(4, 'Erro na emissão de nota fiscal', 1);
