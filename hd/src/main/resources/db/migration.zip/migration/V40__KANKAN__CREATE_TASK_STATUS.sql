INSERT INTO KANBAN.TB_TASK_STATUS (description) VALUES
('To do'), ('In Progress'), ('Testing'), ('Done')