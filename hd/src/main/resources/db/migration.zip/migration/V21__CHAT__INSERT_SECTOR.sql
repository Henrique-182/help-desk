INSERT INTO CHAT.TB_SECTOR (DESCRIPTION)
VALUES ('Sector A'), ('Sector B'), ('Sector C');
 