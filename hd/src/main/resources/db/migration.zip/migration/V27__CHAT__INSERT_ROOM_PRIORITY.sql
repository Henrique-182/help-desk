INSERT INTO CHAT.TB_ROOM_PRIORITY (DESCRIPTION) VALUES
('Very High'), ('High'), ('Normal'), ('Low'), ('Very Low');
