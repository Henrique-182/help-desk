INSERT INTO KNOWLEDGE.TB_KNOWLEDGE (TITLE, FK_SOFTWARE, CONTENT) VALUES 
('Title Knowledge A', 1, 'Content Knowledge A'),
('Title Knowledge AA', 1, 'Content Knowledge AA'),
('Title Knowledge B', 2, 'Content Knowledge B'),
('Title Knowledge BB', 2, 'Content Knowledge BB'),
('Title Knowledge C', 3, 'Content Knowledge C'),
('Title Knowledge CC', 3, 'Content Knowledge CC');
