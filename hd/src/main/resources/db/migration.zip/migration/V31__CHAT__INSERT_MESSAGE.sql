INSERT INTO chat.tb_message (fk_room, fk_user, content_type, "content") VALUES 
(1, 3, 0, 'Olá, bom dia! Preciso de ajuda com uma nota rejeitada'),
(1, 3, 0, 'Anydesk 1234567890'),
(1, 2, 0, 'Bom dia! Vou conectar e corrigir'),
(2, 3, 0, 'Olá, bom dia! Preciso falar com o financeiro'),
(3, 3, 0, 'Olá, bom dia! Preciso de ajuda'),
(3, 3, 0, 'Anydesk 0987654321'),
(3, 2, 0, 'Bom dia! Prontinho'),
(4, 3, 0, 'Olá, bom dia!'),
(4, 2, 0, 'Bom dia! Em que posso ajudar?');
