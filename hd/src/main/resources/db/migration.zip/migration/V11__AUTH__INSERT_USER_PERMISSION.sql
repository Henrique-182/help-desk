INSERT INTO AUTH.TB_USER_PERMISSION (fk_user, fk_permission) VALUES
	(1, 1),
	(1, 2),
	(1, 3),
	(2, 2),
	(2, 3),
	(3, 3);
