INSERT INTO AUTH.TB_USER_TYPE (description) VALUES
	('Adm'), ('Employee'), ('Customer');
